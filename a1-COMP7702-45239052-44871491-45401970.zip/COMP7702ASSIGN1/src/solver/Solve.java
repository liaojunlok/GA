package solver;

import problem.*;

import java.awt.geom.Point2D;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Solve {
    public static void main(String[] args) {
        ProblemSpec ps = new ProblemSpec();

        try {
            ps.loadProblem("input1.txt");
        } catch (IOException e) {
            System.out.println("IO Exception occurred.");
        }
        
        //Robot Config
        RobotConfig robot;
        robot = ps.getInitialRobotConfig();
        double robotWidth = 1;
        
        //MovingBox config
        List<Box> mbs = new ArrayList<>(ps.getMovingBoxes());
        Box box1;
        Box box2;
        box1 = mbs.get(0);
        box2 = mbs.get(1);
        MovingBox mb1 = new MovingBox(box1.getPos(), box1.getWidth());
        MovingBox mb2 = new MovingBox(box2.getPos(), box2.getWidth());
        
        //MovingBox End position config
        List<Point2D> mbEnd = new ArrayList<>(ps.getMovingBoxEndPositions());
        Point2D mbEnd1 = new Point2D.Double(mbEnd.get(0).getX(), mbEnd.get(0).getY());
        Point2D mbEnd2 = new Point2D.Double(mbEnd.get(1).getX(), mbEnd.get(1).getY());
         
        Point mbGoal1 = new Point(mbEnd1.getX(), mbEnd1.getY());
        Point mbGoal2 = new Point(mbEnd2.getX(), mbEnd2.getY());
        
        //StaticObstacle config (??"toString"? If error, rewrite --> rect)
        List<StaticObstacle> sos = new ArrayList<>(ps.getStaticObstacles());
        //StaticObstacle so1 = new StaticObstacle(sos.get(0).toString());
        //StaticObstacle so2 = new StaticObstacle(sos.get(1).toString());
        StaticObstacle so1 = sos.get(0);
        StaticObstacle so2 = sos.get(1);

        for(int i = 0; i< 1;i++) {
        Astar aStar1 = new Astar();
        Astar aStar2 = new Astar();
        AstarRobot aStarRobot = new AstarRobot();
        
        aStar1.move(robot, mb1,  mbGoal1, robotWidth, so1, so2);
        aStar2.move(robot, mb2, mbGoal2, robotWidth, so1, so2);
        RobotBoxMoving robotMove1 = new RobotBoxMoving(robot, mb1,  mbGoal1, robotWidth, so1, so2);
        RobotBoxMoving robotMove2 = new RobotBoxMoving(robot, mb2,  mbGoal2, robotWidth, so1, so2);
        outputText.outputT(robot, mb1, mb2);
        }
    }

}