package solver;

import java.awt.geom.Point2D;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import problem.*;

public class AstarRobot implements IMove{
	public static final double MOVE_TETN = 10;
	public static final double MOVE_ANGLE = 5;
	public static final double POINT_MOVE = 1;
	public static final double LENGTH = 10;

	//double x, y;
	//Point RobotPoint = new Point(x, y);
	
	double mbwidth;	//the width of Moving Box.
	double robotWidth;// the width of robot
	double angle;	//the angle of robot.
	Point2D movingBoxPos;	//the Position of Moving Box.
	Point2D robotPos;	//the position of robot.
	RobotConfig robot;	//robot.
	MovingBox movingBox;	//movingBox.
	StaticObstacle staticObstacle1;	//staticObstacle.
	StaticObstacle staticObstacle2;	//staticObstacle.
	Point movingBoxPoint;	//the point of movingBox.
	Point robotPoint1;	//the point1 of robot.
	Point robotPoint2;	//the point2 of robot.
	Point robotPointM; // the medium point of robot.
	Point movingBoxPoint1;//the left point of moving box.
	
	
	/*OpenList*/
	Map<String, Point> openMap = new HashMap<String, Point>();
	/*CloseList*/
	Map<String, Point> closeMap = new HashMap<String, Point>();
	/*Obstacle*/
	//Set<Point> barrier;
	/*Start Point*/
	Point startPoint;
	/*End Point*/
	Point endPoint;
	/*Current Point*/
	Point currentPoint;
	/*times of loop, in case target is unreachable*/
	int num = 0;
	
	Point lastPoint;
	
	/**
	 * the best way from point1 to point2 
	 * @param x1, y1, x2, y2
	 */
	/**
	 * initial all the @param
	 * @param robot
	 * @param movingBox
	 * @param staticObstacle
	 */
	public void initial(RobotConfig robot, double robotWidth, MovingBox movingBox, StaticObstacle staticObstacle1
			,StaticObstacle staticObstacle2) {
		this.movingBox = movingBox;
		this.robot = robot;
		this.staticObstacle1 = staticObstacle1;
		this.staticObstacle2 = staticObstacle2;
		this.angle = robot.getOrientation();
		this.robotWidth = robotWidth;
		mbwidth = movingBox.getWidth();
		movingBoxPos = movingBox.getPos();
		robotPos = robot.getPos();
		
		movingBoxPoint = new Point(movingBox.pos.getX(), movingBox.pos.getY());
		movingBoxPoint1 = new Point(movingBoxPoint.x - mbwidth/2, movingBoxPoint.y - mbwidth/2);
		robotPoint1 = new Point(robot.getX1(angle), robot.getY1(angle));//the left point of robot -> Point1
		robotPoint2 = new Point(robot.getX2(angle), robot.getY2(angle));//the right point of robot -> Point2
		robotPointM = new Point(robot.getPos().getX(), robot.getPos().getY());// the central point of robot -> Point
	}
	

	/**
	 * the best way between robot to goal
	 * @param robot
	 * @param movingBox
	 * @param goal
	 * @param staticObstacle
	 * 
	 */
	@Override
	public Point move(RobotConfig robot, MovingBox movingBox, Point goal, double robotWidth,
			StaticObstacle staticObstacle1, StaticObstacle staticObstacle2) {
		num = 0;
		initial(robot, robotWidth, movingBox, staticObstacle1, staticObstacle2);
		//movingBox = new MovingBox(movingBoxPos, mbwidth);
		robot = new RobotConfig(robotPos, angle);
		robotPointM = new Point(robot.getPos().getX(), robot.getPos().getY());
		//mbwidth = movingBox.getWidth();
		this.lastPoint = goal;
		this.staticObstacle1 = staticObstacle1;
		this.staticObstacle2 = staticObstacle2;
		this.startPoint = new Point(robot.getPos().getX(), robot.getPos().getY());
		Point endPoint = goal;
		this.endPoint = this.getNearPoint(endPoint, endPoint, angle);
		this.closeMap.put(startPoint.getKey(), startPoint);
		this.currentPoint = this.startPoint;
		this.toOpen(robot.getPos().getX(), robot.getPos().getY(), angle);
		outputText.outputT(robot, movingBox, movingBox);
		return endPoint;
	}



	/**
	 * check the collision of Moving Box
	 */
	/*public boolean CollisionMovingBox(Point point) {
		if(Math.abs(point.x - (staticObstacle.getRect().getX()+staticObstacle.getRect().getWidth()/2)) 
				<= (staticObstacle.getRect().getWidth()/2 + mbwidth/2) && 
				(Math.abs(point.y - (staticObstacle.getRect().getY() + staticObstacle.getRect().getHeight()/2)))
				<= (staticObstacle.getRect().getHeight()/2 + mbwidth/2)) {
			return true;
		} else {
			return false;	
		}
	}*/
	
	
	public boolean CollisionRobot(Point point) {
		//double mx = (point.x - robotWidth/2) + (movingBoxPoint1.x - (point.x - robotWidth/2));
		//double my = Math.tan(angle) * (movingBoxPoint1.x - (point.x - robotWidth/2));
		//double sx = staticObstacle.getRect().getX() + ((point.x - robotWidth/2) - staticObstacle.getRect().getX());
		//double sy = Math.tan(angle) * ((point.x - robotWidth/2) - staticObstacle.getRect().getX());
		double rbx;
		double rby;
		if(angle == 0 || angle == 180) {
			rbx = point.x + robotWidth/2;
			rby = point.y;
			for(double i = point.x - robotWidth/2; i <= rbx; i++){
				if(i >= staticObstacle1.getRect().getX() 
				&& i <= (staticObstacle1.getRect().getX() + staticObstacle1.getRect().getWidth())
				&& point.y >= staticObstacle1.getRect().getY()
				&& point.y <= (staticObstacle1.getRect().getY() + staticObstacle1.getRect().getHeight())) {
					return true;
				}
				if(i >= staticObstacle2.getRect().getX() 
				&& i <= (staticObstacle2.getRect().getX() + staticObstacle2.getRect().getWidth())
				&& point.y >= staticObstacle2.getRect().getY()
				&& point.y <= (staticObstacle2.getRect().getY() + staticObstacle2.getRect().getHeight())) {
					return true;
				}
			}
		}
		else if(angle == 90) {
			rbx = point.x - robotWidth/2;
			rby = point.y + robotWidth/2;
			for(double i = point.y - robotWidth/2; i <= rby; i++) {
				if(point.x >= staticObstacle1.getRect().getX() 
				&& point.x <= (staticObstacle1.getRect().getX() + staticObstacle1.getRect().getWidth())
				&& i >= staticObstacle1.getRect().getY()
				&& i <= (staticObstacle1.getRect().getY() + staticObstacle1.getRect().getHeight())) {
					return true;
				}
				if(point.x >= staticObstacle2.getRect().getX() 
						&& point.x <= (staticObstacle2.getRect().getX() + staticObstacle2.getRect().getWidth())
						&& i >= staticObstacle2.getRect().getY()
						&& i <= (staticObstacle2.getRect().getY() + staticObstacle2.getRect().getHeight())) {
							return true;
						}
				
			}
		}
		else {
			rbx = point.x + Math.cos(Math.toRadians(angle)) * robotWidth/2;// the right point of robot -> x2
			rby = point.y + Math.sin(Math.toRadians(angle)) * robotWidth/2;// the right point of robot -> y2
			//int x1 = (int) rbx;
			//int y1 = (int) rby;
			for(double i = point.x - robotWidth/2; i <= rbx; i++) {
				for(double j = point.y - robotWidth/2; j <= rby ; j++) {
				if(i >= staticObstacle1.getRect().getX() 
						&& i <= (staticObstacle1.getRect().getX() + staticObstacle1.getRect().getWidth())
						&& j >= staticObstacle1.getRect().getY()
						&& j <= (staticObstacle1.getRect().getY() + staticObstacle1.getRect().getHeight())) {
					return true;
				}
				if(i >= staticObstacle2.getRect().getX() 
						&& i <= (staticObstacle2.getRect().getX() + staticObstacle2.getRect().getWidth())
						&& j >= staticObstacle2.getRect().getY()
						&& j <= (staticObstacle2.getRect().getY() + staticObstacle2.getRect().getHeight())) {
					return true;
				}
				if(rbx >= staticObstacle1.getRect().getX() 
						&& rbx <= (staticObstacle1.getRect().getX() + staticObstacle1.getRect().getWidth())
						&& rby >= staticObstacle1.getRect().getY()
						&& rby <= (staticObstacle1.getRect().getY() + staticObstacle1.getRect().getHeight())) {
					return true;
				}
				if(rbx >= staticObstacle2.getRect().getX() 
						&& rbx <= (staticObstacle2.getRect().getX() + staticObstacle2.getRect().getWidth())
						&& rby >= staticObstacle2.getRect().getY()
						&& rby <= (staticObstacle2.getRect().getY() + staticObstacle2.getRect().getHeight())) {
					return true;
				}
				continue;
				}
				
				
			}
		}
			return false;
	}
	
	/**
	 * check the point whether is in staticObstacle or not
	 * @param point
	 */
	public boolean PointInStaticObstacle(Point point) {
		if(point.x >= staticObstacle1.getRect().getX() 
				&& point.x <= (staticObstacle1.getRect().getX() + staticObstacle1.getRect().getWidth())
				&& point.y >= staticObstacle1.getRect().getY()
				&& point.y <= (staticObstacle1.getRect().getY() + staticObstacle1.getRect().getHeight())) {
			return true;
		}
		if(point.x >= staticObstacle2.getRect().getX() 
				&& point.x <= (staticObstacle2.getRect().getX() + staticObstacle2.getRect().getWidth())
				&& point.y >= staticObstacle2.getRect().getY()
				&& point.y <= (staticObstacle2.getRect().getY() + staticObstacle2.getRect().getHeight())) {
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	 * heuristic cost  between p1 to p2
	 * 1.Euclidean Distance
	 * 2.Manhattan Distance
	 * 3.Euclidean Distance in sqrt
	 */
	private double getGuessLength(double x1, double y1, double x2, double y2, double angle) {
		//return ((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)) * Astar.LENGTH;
		return (Math.abs(x1 - x2) + Math.abs(y1 - y2)) * Astar.LENGTH + Math.abs(angle - getAngle(new Point(x1, y1)));
		//return Math.max(Math.abs(x1 - x2), Math.abs(y1 - y2)) * Astar.LENGTH；
		
	}
	/**
	 * add neighbors of points to OpenList
	 * @param x1
	 * @param y1
	 */

	private void toOpen(double x, double y, double angle) {
		// TODO Auto-generated method stub
		this.addOpenPoint(new Point(x - AstarRobot.POINT_MOVE, y), angle, AstarRobot.MOVE_TETN);
		this.addOpenPoint(new Point(x + AstarRobot.POINT_MOVE, y), angle, AstarRobot.MOVE_TETN);
		this.addOpenPoint(new Point(x, y - AstarRobot.POINT_MOVE), angle, AstarRobot.MOVE_TETN);
		this.addOpenPoint(new Point(x, y + AstarRobot.POINT_MOVE), angle, AstarRobot.MOVE_TETN);
		this.addOpenPoint(new Point(x, y), angle + MOVE_ANGLE, AstarRobot.MOVE_ANGLE);
		this.addOpenPoint(new Point(x, y), angle - MOVE_ANGLE, AstarRobot.MOVE_ANGLE);
		num++;
		if(num <= 4000) {
			this.toClose(x, y, angle);
		}
		
	}
	
	/**
	 * add neighbors of points to CloseList
	 * @param x
	 * @param y
	 */

	private void toClose(double x, double y, double angle) {
		// TODO Auto-generated method stub
		List<Point> list = new ArrayList<Point>(openMap.values());
		Collections.sort(list, new Comparator<Point>(){

			@Override
			public int compare(Point o1, Point o2) {
				// TODO Auto-generated method stub
				
				if(o1.fTotal > o2.fTotal) {
					return 1;
				}
				else if(o1.fTotal < o2.fTotal) {
					return -1;
				}
				else {
					return 0;
				}
			}
		});
		if(list.size() > 0) {
			this.currentPoint = list.get(0);
			closeMap.put(this.currentPoint.getKey(), this.currentPoint);
			openMap.remove(this.currentPoint.getKey());
			if(!currentPoint.equals(endPoint)) {
				this.toOpen(this.currentPoint.x, this.currentPoint.y, angle);
			}else {
				endPoint = this.currentPoint;
			}
		}
	}
	/**
	 * add open point
	 * @param point
	 * @param gCost
	 * 
	 */

	private void addOpenPoint(Point point, double angle, double gCost) {
		// TODO Auto-generated method stub
		if(point.x < 0 || point.y <0) {
			return;
		}
		String key = point.getKey();
		if(!CollisionRobot(point) && !point.equals(this.currentPoint)) {
			double hEstimate = this.getGuessLength(point.x, point.y,
					this.endPoint.x, this.endPoint.y, angle);
			double totalGCost = this.currentPoint.gCost + gCost;
			double fTotal = totalGCost + hEstimate;
			if(!closeMap.containsKey(key)) {
				point.hEstimate = hEstimate;
				point.gCost = totalGCost;
				point.fTotal = fTotal;
				Point oldPoint = openMap.get(key);
				if(oldPoint != null) {
					if(oldPoint.gCost > totalGCost) {
						oldPoint.fTotal = fTotal;
						oldPoint.prev = this.currentPoint;
						openMap.put(key, oldPoint);
					}
				} else {
					point.prev = this.currentPoint;
					openMap.put(key, point);
				}
			} else {
				Point oldPoint = closeMap.get(key);
				if(oldPoint != null) {
					if((oldPoint.gCost + gCost) < this.currentPoint.gCost) {
						if(this.currentPoint.prev != oldPoint) {
							this.currentPoint.fTotal = oldPoint.fTotal + gCost;
							this.currentPoint.gCost = oldPoint.gCost + gCost;
							this.currentPoint.prev = oldPoint;
						}
					}
				}
			}
		}
		
	}

	Map<String, Point> nearOutMap;
	

	private Point getNearPoint(Point point1, Point point2, double angle) {
		// TODO Auto-generated method stub
		if(PointInStaticObstacle(point1)) {
			nearOutMap = new HashMap<String, Point>();
			this.endPoint = point1;
			this.toNearPoint(point1, point2, angle);
			List<Point> nearList = new ArrayList<Point>(nearOutMap.values());
			Collections.sort(nearList, new Comparator<Point>() {

				@Override
				public int compare(Point o1, Point o2) {
					// TODO Auto-generated method stub
					if(o1.gCost > o2.gCost) {
						return 1;
					} else if(o1.gCost < o2.gCost) {
						return -1;
					} else {
						return 0;
					}
				}
				
			});
			this.openMap = new HashMap<String, Point>();
			this.closeMap = new HashMap<String, Point>();
			if(nearList.size() > 0) {
				return nearList.get(0);
			} else {
				return point1;
			}
		} else {
			return point1;
		}
	}

	private void toNearPoint(Point point1, Point point2, double angle) {
		// TODO Auto-generated method stub
		double x = point1.x;
		double y = point1.y;
		this.addNearOpenPoint(new Point(x - 1, y), point2, angle);
		this.addNearOpenPoint(new Point(x + 1, y), point2, angle);
		this.addNearOpenPoint(new Point(x, y - 1), point2, angle);
		this.addNearOpenPoint(new Point(x, y + 1), point2, angle);
		this.addNearOpenPoint(new Point(x, y), point2, angle + 5);
		this.addNearOpenPoint(new Point(x, y), point2, angle - 5);
		if(this.nearOutMap.size() == 0) {
			List<Point> list = new ArrayList<Point>(openMap.values());
			Collections.sort(list, new Comparator<Point>() {

				@Override
				public int compare(Point o1, Point o2) {
					// TODO Auto-generated method stub
					double l1 = o1.gCost;
					double l2 = o2.gCost;
					if(l1 > l2) {
						return 1;
					} else if(l1 < l2){
						return -1;
					} else {
						return 0;
					}
				}
				
			});
			if(list.size() > 0) {
				Point p = list.get(0);
				this.closeMap.put(p.getKey(), p);
				this.openMap.remove(p.getKey());
				this.toNearPoint(list.get(0), point2, angle);
			}
		}
	}

	private void addNearOpenPoint(Point point1, Point point2, double angle) {
		// TODO Auto-generated method stub
		String key = point1.getKey();
		double gCost = this.getGuessLength(point1.x, point1.y, 
				point2.x, point2.y, angle);
		point1.gCost = gCost;
		if(PointInStaticObstacle(point1)) {
				if(!this.openMap.containsKey(key) && !this.closeMap.containsKey(key)) {
					this.openMap.put(key, point1);
				}
			} else {
				this.nearOutMap.put(key, point1);
			}	
	}
		public Map<String, Point> getOpenMap(){
			return openMap;
		}
		
		public void setOpenMap(Map<String, Point> openMap) {
			this.openMap = openMap;
		}
		
		public Map<String, Point> getCloseMap(){
			return closeMap;
		}
		
		public void setCloseMap(Map<String, Point> closeMap) {
			this.closeMap = closeMap;
		}
		
		/*public Set<Point> getBarrier() {
			return barrier;
		}
		
		public void setBarrier(Set<Point> barrier) {
			this.barrier = barrier;
		}
		*/
		
		public Point getEndPoint() {
			return endPoint;
		}
		
		public void setEndPoint(Point endPoint) {
			this.endPoint = endPoint;
		}
		
		public Point getStartPoint() {
			return startPoint;
		}
		
		public void setStartPoint(Point startPoint) {
			this.startPoint = startPoint;
		}
		
		public double getAngle(Point goal) {
			double angle = robot.getOrientation();
			if(movingBox.pos.getX() - mbwidth/2 == goal.x && movingBox.pos.getY() == goal.y) {
				angle = 90;
			}
			if(movingBox.pos.getX() == goal.x && movingBox.pos.getY() + mbwidth/2 == goal.y
					||movingBox.pos.getY() - mbwidth/2 == goal.y) {
				angle = 0;
			}
			return angle;
		}
		
		
		
		
	

}
