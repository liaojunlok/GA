package solver;

import java.awt.geom.Point2D;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import problem.MovingBox;
import problem.RobotConfig;
import problem.StaticObstacle;

public class RobotBoxMoving {
	double mbwidth;	//the width of Moving Box.
	double robotWidth;// the width of robot
	double angle;	//the angle of robot.
	Point2D movingBoxPos;	//the Position of Moving Box.
	Point2D robotPos;	//the position of robot.
	RobotConfig robot;	//robot.
	MovingBox movingBox;	//movingBox.
	StaticObstacle staticObstacle1;	//staticObstacle.
	StaticObstacle staticObstacle2;	//staticObstacle.
	Point movingBoxPoint;	//the point of movingBox.
	Point robotPoint1;	//the point1 of robot.
	Point robotPoint2;	//the point2 of robot.
	Point robotPointM; // the medium point of robot.
	Point movingBoxPoint1;//the left point of moving box.
	
	public void initial(RobotConfig robot, double robotWidth, MovingBox movingBox, StaticObstacle staticObstacle1
			,StaticObstacle staticObstacle2) {
		this.movingBox = movingBox;
		this.robot = robot;
		this.staticObstacle1 = staticObstacle1;
		this.staticObstacle2 = staticObstacle2;
		this.angle = robot.getOrientation();
		this.robotWidth = robotWidth;
		mbwidth = movingBox.getWidth();
		movingBoxPos = movingBox.getPos();
		robotPos = robot.getPos();
		
		movingBoxPoint = new Point(movingBox.pos.getX(), movingBox.pos.getY());
		movingBoxPoint1 = new Point(movingBoxPoint.x - mbwidth/2, movingBoxPoint.y - mbwidth/2);
		robotPoint1 = new Point(robot.getX1(angle), robot.getY1(angle));//the left point of robot -> Point1
		robotPoint2 = new Point(robot.getX2(angle), robot.getY2(angle));//the right point of robot -> Point2
		robotPointM = new Point(robot.getPos().getX(), robot.getPos().getY());// the central point of robot -> Point
	}
	public RobotBoxMoving(RobotConfig robot, MovingBox movingBox, Point goal, double robotWidth,
			StaticObstacle staticObstacle1, StaticObstacle staticObstacle2) {
		
		Astar aStar = new Astar();
		AstarRobot aStarRobot = new AstarRobot();
		initial(robot, robotWidth, movingBox, staticObstacle1, staticObstacle2);
		//Point2D pos1 = new Point2D.Double(30, 30);
		//Point2D pos2 = new Point2D.Double(25, 25);
		double w = 5;
		//double robotWidth = 5;
		//double angle = 90;
		//robot = new RobotConfig(pos1, angle);
		//Point goal = new Point(5, 5);
		//StaticObstacle so1 = new StaticObstacle(15, 15, 5, 5);
		//StaticObstacle so2 = new StaticObstacle(10, 10, 3, 3);
		//MovingBox mb = new MovingBox(pos2, w);
		long start = System.currentTimeMillis();
		for (int i = 0; i < 1; i++) {
			aStar = new Astar();
			aStarRobot = new AstarRobot();
			//aStarRobot.move(robot, mb, goal, robotWidth, so);
			aStar.move(robot, movingBox, goal, angle, staticObstacle1, staticObstacle2);
		}
		long end = System.currentTimeMillis();
		System.out.println(end - start);
		Queue<Point> queue = new LinkedList<Point>();
		Point endPoint = aStar.getEndPoint();
		Point startPoint = aStar.getStartPoint();
		Map<String, Point> openMap = aStar.getOpenMap();
		Map<String, Point> closeMap = aStar.getCloseMap();
		queue = RobotBoxMoving.get(endPoint, queue);
		Point p = startPoint;
		Point nextP;
			while(queue != null) {
				nextP = queue.poll();
				if(p.y == nextP.y && p.x < nextP.x) {
					Point robotGoal = new Point(p.x - w/2, p.y);
					aStarRobot.move(robot, movingBox, robotGoal, robotWidth, staticObstacle1, staticObstacle2);
					/*for(double i = robot.getOrientation(); i <= 90; i+= 0.02) {
						System.out.println(i);
					}*/
					this.angle = 90;
					Point2D pos = new Point2D.Double(robotGoal.x, robotGoal.y);
					robot = new RobotConfig(pos, angle);
				}
				if(p.y == nextP.y && p.x > nextP.x) {
					Point robotGoal = new Point(p.x + w/2, p.y);
					aStarRobot.move(robot, movingBox, robotGoal, robotWidth, staticObstacle1, staticObstacle2);
					/*for(double i = robot.getOrientation(); i <= 90; i+= 0.02) {
						System.out.println(i);
					}*/
					this.angle = 90;
					Point2D pos = new Point2D.Double(robotGoal.x, robotGoal.y);
					robot = new RobotConfig(pos, angle);
				}
				if(p.x == nextP.x && p.y > nextP.y) {
					Point robotGoal = new Point(p.x, p.y + w/2);
					aStarRobot.move(robot, movingBox, robotGoal, robotWidth, staticObstacle1, staticObstacle2);
					this.angle = 0;
					Point2D pos = new Point2D.Double(robotGoal.x, robotGoal.y);
					robot = new RobotConfig(pos, angle);
				}
				if(p.x == nextP.x && p.y < nextP.y) {
					Point robotGoal = new Point(p.x, p.y - w/2);
					aStarRobot.move(robot, movingBox, robotGoal, robotWidth, staticObstacle1, staticObstacle2);
					this.angle = 0;
					Point2D pos = new Point2D.Double(robotGoal.x, robotGoal.y);
					robot = new RobotConfig(pos, angle);
				}
				p = nextP;	
		}
	}
	public static Queue<Point> get(Point p, Queue<Point> queue) {
		if(p != null) {
			queue.add(p);
		}
		Point pp = p.prev;
		if(pp != null) {
			RobotBoxMoving.get(pp, queue);
		} else {
			return queue;
		}
		return queue;
	}
	
	public double getAngle() {
		return angle;
	}

}
