package solver;

import java.awt.geom.Point2D;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
 
import org.junit.Test;

import problem.MovingBox;
import problem.RobotConfig;
import problem.StaticObstacle;
 
public class TestPoint {
	@Test
	public void test2() {
		Astar aStar1 = new Astar();
		Astar aStar2 = new Astar();
		AstarRobot aStarRobot = new AstarRobot();
		//Set<Point> barrier = new HashSet<Point>();

		Point2D pos1 = new Point2D.Double(30, 30);
		Point2D pos2 = new Point2D.Double(15, 50);
		double w = 5;
		double angle = 180;
		RobotConfig robot = new RobotConfig(pos1, angle);
		Point goal = new Point(5, 5);
		StaticObstacle so1 = new StaticObstacle(15, 15, 5, 5);
		StaticObstacle so2 = new StaticObstacle(10, 10, 3, 3);
		MovingBox mb1 = new MovingBox(pos1, w);
		MovingBox mb2 = new MovingBox(pos2, w);
		long start = System.currentTimeMillis();
		for (int i = 0; i < 1; i++) {
			aStar1 = new Astar();
			aStar2 = new Astar();
			aStarRobot = new AstarRobot();
			aStarRobot.move(robot, mb1, goal, 6, so1, so2);
			aStar1.move(robot, mb1, goal, 5, so1, so2);
			aStar2.move(robot, mb2, goal, 6, so1, so2);
		}
		long end = System.currentTimeMillis();
		System.out.println(end - start);
		Set<Point> set = new HashSet<Point>();
		Set<Point> set2 = new HashSet<Point>();
		
		Point endPoint = aStar1.getEndPoint();
		Point startPoint = aStar1.getStartPoint();
		Map<String, Point> openMap = aStar1.getOpenMap();
		Map<String, Point> closeMap = aStar1.getCloseMap();
		
		
		Point endPoint2 = aStar2.getEndPoint();
		Point startPoint2 = aStar2.getStartPoint();
		Map<String, Point> openMap2 = aStar2.getOpenMap();
		Map<String, Point> closeMap2 = aStar2.getCloseMap();
		
		/*Point endPoint = aStarRobot.getEndPoint();
		Point startPoint = aStarRobot.getStartPoint();
		Map<String, Point> openMap = aStarRobot.getOpenMap();
		Map<String, Point> closeMap = aStarRobot.getCloseMap();
		*/
		set = TestPoint.get(endPoint, set);
		set2 = TestPoint.get(endPoint2, set2);
		
		/**
		 * 显示最佳路径
		 */
		//System.out.println(aStar.getEndPoint().getKey());
		System.out.println(aStarRobot.getEndPoint().getKey());
		for (int i = 0; i < 70; i++) {
			for (int j = 0; j < 70; j++) {
				Point p = new Point(j, i);
				//if (p.equals(aStar.getEndPoint())) {
				if (p.equals(aStarRobot.getEndPoint())) {
					System.out.print("o");
				} else if (p.equals(startPoint)) {
					System.out.print("^");
				} else {
					if (set.contains(p)) {
						System.out.print("@");
					} else if ((p.x >= so1.getRect().getX() 
							&& p.x <= (so1.getRect().getX() + so1.getRect().getWidth())
							&& p.y >= so1.getRect().getY()
							&& p.y <= (so1.getRect().getY() + so1.getRect().getHeight()))
							||(p.x >= so2.getRect().getX() 
									&& p.x <= (so2.getRect().getX() + so2.getRect().getWidth())
									&& p.y >= so2.getRect().getY()
									&& p.y <= (so2.getRect().getY() + so2.getRect().getHeight()))) {
						System.out.print("#");
					} else {
						System.out.print("*");
					}
 
				}
				System.out.print(" ");
			}
			System.out.println();
		}
 
		System.out.println("--------------------------------------------------------------------------------------------------------");
		/**
		 * 扫描的范围
		 */
		for (int i = 0; i < 70; i++) {
			for (int j = 0; j < 70; j++) {
				Point p = new Point(j, i);
				if (p.equals(endPoint)) {
					System.out.print("o");
				} else if (p.equals(startPoint)) {
					System.out.print("^");
				} else {
					if (openMap.containsKey(p.getKey())) {
						System.out.print("%");
					} else if (closeMap.containsKey(p.getKey())) {
						System.out.print("@");
					} else if ((p.x >= so1.getRect().getX() 
							&& p.x <= (so1.getRect().getX() + so1.getRect().getWidth())
							&& p.y >= so1.getRect().getY()
							&& p.y <= (so1.getRect().getY() + so1.getRect().getHeight()))
							||(p.x >= so2.getRect().getX() 
									&& p.x <= (so2.getRect().getX() + so2.getRect().getWidth())
									&& p.y >= so2.getRect().getY()
									&& p.y <= (so2.getRect().getY() + so2.getRect().getHeight()))) {
						System.out.print("#");
					} else {
						System.out.print("*");
					}
 
				}
				System.out.print(" ");
			}
			System.out.println();
		}
 /////////////////////////////////////////////////////////////////////////////
		System.out.println(aStar2.getEndPoint().getKey());
		for (int i = 0; i < 70; i++) {
			for (int j = 0; j < 70; j++) {
				Point p = new Point(j, i);
				//if (p.equals(aStar.getEndPoint())) {
				if (p.equals(aStar2.getEndPoint())) {
					System.out.print("o");
				} else if (p.equals(startPoint2)) {
					System.out.print("^");
				} else {
					if (set2.contains(p)) {
						System.out.print("@");
					} else if ((p.x >= so1.getRect().getX() 
							&& p.x <= (so1.getRect().getX() + so1.getRect().getWidth())
							&& p.y >= so1.getRect().getY()
							&& p.y <= (so1.getRect().getY() + so1.getRect().getHeight()))
							||(p.x >= so2.getRect().getX() 
									&& p.x <= (so2.getRect().getX() + so2.getRect().getWidth())
									&& p.y >= so2.getRect().getY()
									&& p.y <= (so2.getRect().getY() + so2.getRect().getHeight()))) {
						System.out.print("#");
					} else {
						System.out.print("*");
					}

				}
				System.out.print(" ");
			}
			System.out.println();
		}

		System.out.println("--------------------------------------------------------------------------------------------------------");
		
		/**
		 * 扫描的范围
		 */
		for (int i = 0; i < 100; i++) {
			for (int j = 0; j < 100; j++) {
				Point p = new Point(j, i);
				if (p.equals(endPoint2)) {
					System.out.print("o");
				} else if (p.equals(startPoint2)) {
					System.out.print("^");
				} else {
					if (openMap2.containsKey(p.getKey())) {
						System.out.print("%");
					} else if (closeMap2.containsKey(p.getKey())) {
						System.out.print("@");
					} else if ((p.x >= so1.getRect().getX() 
							&& p.x <= (so1.getRect().getX() + so1.getRect().getWidth())
							&& p.y >= so1.getRect().getY()
							&& p.y <= (so1.getRect().getY() + so1.getRect().getHeight()))
							||(p.x >= so2.getRect().getX() 
									&& p.x <= (so2.getRect().getX() + so2.getRect().getWidth())
									&& p.y >= so2.getRect().getY()
									&& p.y <= (so2.getRect().getY() + so2.getRect().getHeight()))) {
						System.out.print("#");
					} else {
						System.out.print("*");
					}
 
				}
				System.out.print(" ");
			}
			System.out.println();
		}
	}
	
	
	public static Set<Point> get(Point p, Set<Point> set) {
		if (p != null) {
			set.add(p);
		}
		Point pp = p.prev;
		if (pp != null) {
			TestPoint.get(pp, set);
		} else {
			return set;
		}
		return set;
	}
	
	
}
