package solver;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import problem.MovingBox;
import problem.RobotConfig;
import problem.StaticObstacle;

public class Astar implements IMove{
	
	public static final double MOVE_TETN = 10;
	//public static final int MOVE_SIDE = 14;
	public static final double LENGTH = 10;

	//double x, y;
	//Point RobotPoint = new Point(x, y);
	
	double mbwidth;	//the width of Moving Box.
	double angle;	//the angle of robot.
	Point2D movingBoxPos;	//the Position of Moving Box.
	Point2D robotPos;	//the position of robot.
	RobotConfig robot;	//robot.
	MovingBox movingBox;	//movingBox
	StaticObstacle staticObstacle1;	//staticObstacle
	StaticObstacle staticObstacle2;	//staticObstacle
	Point movingBoxPoint;	//movingBox
	//Set<Point> StaticObstacle;
	
	/*OpenList*/
	Map<String, Point> openMap = new HashMap<String, Point>();
	/*CloseList*/
	Map<String, Point> closeMap = new HashMap<String, Point>();
	/*Obstacle*/
	//Set<Point> barrier;
	/*Start Point*/
	Point startPoint;
	/*End Point*/
	Point endPoint;
	/*Current Point*/
	Point currentPoint;
	/*times of loop, in case target is unreachable*/
	int num = 0;
	
	Point lastPoint;
	
	/**
	 * the best way from point1 to point2 
	 * @param x1, y1, x2, y2
	 */
	/*@Override
	public Point move(double x1, double y1, double x2, double y2, Set<Point> barrier) {
		// TODO Auto-generated method stub
		num = 0;
		this.lastPoint = new Point(x2, y2);
		//this.barrier = barrier;
		this.startPoint = new Point(x1, y1);
		Point endPoint = new Point(x2, y2);
		this.endPoint = this.getNearPoint(endPoint, endPoint);
		this.closeMap.put(startPoint.getKey(), startPoint);
		this.currentPoint = this.startPoint;
		this.toOpen(x1, y1);
		return endPoint;
	}
	*/
	/**
	 * initial all the @param
	 * @param robot
	 * @param movingBox
	 * @param staticObstacle
	 */
	public void initial(RobotConfig robot, MovingBox movingBox, StaticObstacle staticObstacle1,StaticObstacle staticObstacle2) {
		this.movingBox = movingBox;
		this.robot = robot;
		this.staticObstacle1 = staticObstacle1;
		this.staticObstacle2 = staticObstacle2;
		mbwidth = movingBox.getWidth();
		movingBoxPos = movingBox.getPos();
		movingBoxPoint = new Point(movingBox.pos.getX(), movingBox.pos.getY());
	}
	
	/**
	 * the best way between movingBox to goal
	 * @param robot
	 * @param movingBox
	 * @param goal
	 * @param staticObstacle
	 * 
	 */
	@Override
	public Point move(RobotConfig robot, MovingBox movingBox, Point goal, double robotWidth,
			StaticObstacle staticObstacle1, StaticObstacle staticObstacle2) {
		num = 0;
		initial(robot, movingBox, staticObstacle1, staticObstacle2);
		movingBox = new MovingBox(movingBoxPos, mbwidth);
		//robot = new RobotConfig(robotPos, angle);
		movingBoxPoint = new Point(movingBox.pos.getX(),movingBox.pos.getY());
		mbwidth = movingBox.getWidth();
		this.lastPoint = goal;
		this.staticObstacle1 = staticObstacle1;
		this.staticObstacle2 = staticObstacle2;
		this.startPoint = new Point(movingBox.pos.getX(), movingBox.pos.getY());
		Point endPoint = goal;
		this.endPoint = this.getNearPoint(endPoint, endPoint);
		this.closeMap.put(startPoint.getKey(), startPoint);
		this.currentPoint = this.startPoint;
		this.toOpen(movingBox.pos.getX(), movingBox.pos.getY());
		return endPoint;
	}
	/**
	 * check the collision of Moving Box
	 */
	public boolean Collision(Point point) {
		if(Math.abs(point.x - (staticObstacle1.getRect().getX()+staticObstacle1.getRect().getWidth()/2)) 
				<= (staticObstacle1.getRect().getWidth()/2 + mbwidth/2) && 
				(Math.abs(point.y - (staticObstacle1.getRect().getY() + staticObstacle1.getRect().getHeight()/2)))
				<= (staticObstacle1.getRect().getHeight()/2 + mbwidth/2)) {
			return true;
		} 
		if(Math.abs(point.x - (staticObstacle2.getRect().getX()+staticObstacle2.getRect().getWidth()/2)) 
				<= (staticObstacle2.getRect().getWidth()/2 + mbwidth/2) && 
				(Math.abs(point.y - (staticObstacle2.getRect().getY() + staticObstacle2.getRect().getHeight()/2)))
				<= (staticObstacle2.getRect().getHeight()/2 + mbwidth/2)) {
			return true;
		} 
		else {
			return false;	
		}
	}
	
	/**
	 * check the point whether is in staticObstacle or not
	 * @param point
	 */
	public boolean PointInStaticObstacle(Point point) {
		if(point.x >= staticObstacle1.getRect().getX() 
				&& point.x <= (staticObstacle1.getRect().getX() + staticObstacle1.getRect().getWidth())
				&& point.y >= staticObstacle1.getRect().getY()
				&& point.y <= (staticObstacle1.getRect().getX() + staticObstacle1.getRect().getHeight())) {
			return true;
		}
		if(point.x >= staticObstacle2.getRect().getX() 
				&& point.x <= (staticObstacle2.getRect().getX() + staticObstacle2.getRect().getWidth())
				&& point.y >= staticObstacle2.getRect().getY()
				&& point.y <= (staticObstacle2.getRect().getX() + staticObstacle2.getRect().getHeight())) {
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	 * heuristic cost  between p1 to p2
	 * 1.Euclidean Distance
	 * 2.Manhattan Distance
	 * 3.Euclidean Distance in sqrt
	 */
	private double getGuessLength(double x1, double y1, double x2, double y2) {
		//return ((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)) * Astar.LENGTH;
		return (Math.abs(x1 - x2) + Math.abs(y1 - y2)) * Astar.LENGTH;
		//return Math.max(Math.abs(x1 - x2), Math.abs(y1 - y2)) * Astar.LENGTH；
		
	}
	/**
	 * add neighbors of points to OpenList
	 * @param x1
	 * @param y1
	 */

	private void toOpen(double x, double y) {
		// TODO Auto-generated method stub
		this.addOpenPoint(new Point(x - 1, y), Astar.MOVE_TETN);
		this.addOpenPoint(new Point(x + 1, y), Astar.MOVE_TETN);
		this.addOpenPoint(new Point(x, y - 1), Astar.MOVE_TETN);
		this.addOpenPoint(new Point(x, y + 1), Astar.MOVE_TETN);
		num++;
		if(num <= 4000) {
			this.toClose(x, y);
		}
		
	}
	
	/**
	 * add neighbors of points to CloseList
	 * @param x
	 * @param y
	 */

	private void toClose(double x, double y) {
		// TODO Auto-generated method stub
		List<Point> list = new ArrayList<Point>(openMap.values());
		Collections.sort(list, new Comparator<Point>(){

			@Override
			public int compare(Point o1, Point o2) {
				// TODO Auto-generated method stub
				
				if(o1.fTotal > o2.fTotal) {
					return 1;
				}
				else if(o1.fTotal < o2.fTotal) {
					return -1;
				}
				else {
					return 0;
				}
			}
		});
		if(list.size() > 0) {
			this.currentPoint = list.get(0);
			closeMap.put(this.currentPoint.getKey(), this.currentPoint);
			openMap.remove(this.currentPoint.getKey());
			if(!currentPoint.equals(endPoint)) {
				this.toOpen(this.currentPoint.x, this.currentPoint.y);
			}else {
				endPoint = this.currentPoint;
			}
		}
	}
	/**
	 * add open point
	 * @param point
	 * @param gCost
	 * 
	 */

	private void addOpenPoint(Point point, double gCost) {
		// TODO Auto-generated method stub
		if(point.x < 0 || point.y <0) {
			return;
		}
		String key = point.getKey();
		if(!Collision(point) && !point.equals(this.currentPoint)) {
			double hEstimate = this.getGuessLength(point.x, point.y,
					this.endPoint.x, this.endPoint.y);
			double totalGCost = this.currentPoint.gCost + gCost;
			double fTotal = totalGCost + hEstimate;
			if(!closeMap.containsKey(key)) {
				point.hEstimate = hEstimate;
				point.gCost = totalGCost;
				point.fTotal = fTotal;
				Point oldPoint = openMap.get(key);
				if(oldPoint != null) {
					if(oldPoint.gCost > totalGCost) {
						oldPoint.fTotal = fTotal;
						oldPoint.prev = this.currentPoint;
						openMap.put(key, oldPoint);
					}
				} else {
					point.prev = this.currentPoint;
					openMap.put(key, point);
				}
			} else {
				Point oldPoint = closeMap.get(key);
				if(oldPoint != null) {
					if((oldPoint.gCost + gCost) < this.currentPoint.gCost) {
						if(this.currentPoint.prev != oldPoint) {
							this.currentPoint.fTotal = oldPoint.fTotal + gCost;
							this.currentPoint.gCost = oldPoint.gCost + gCost;
							this.currentPoint.prev = oldPoint;
						}
					}
				}
			}
		}
		
	}

	Map<String, Point> nearOutMap;
	

	private Point getNearPoint(Point point1, Point point2) {
		// TODO Auto-generated method stub
		if(PointInStaticObstacle(point1)) {
			nearOutMap = new HashMap<String, Point>();
			this.endPoint = point1;
			this.toNearPoint(point1, point2);
			List<Point> nearList = new ArrayList<Point>(nearOutMap.values());
			Collections.sort(nearList, new Comparator<Point>() {

				@Override
				public int compare(Point o1, Point o2) {
					// TODO Auto-generated method stub
					if(o1.gCost > o2.gCost) {
						return 1;
					} else if(o1.gCost < o2.gCost) {
						return -1;
					} else {
						return 0;
					}
				}
				
			});
			this.openMap = new HashMap<String, Point>();
			this.closeMap = new HashMap<String, Point>();
			if(nearList.size() > 0) {
				return nearList.get(0);
			} else {
				return point1;
			}
		} else {
			return point1;
		}
	}

	private void toNearPoint(Point point1, Point point2) {
		// TODO Auto-generated method stub
		double x = point1.x;
		double y = point1.y;
		this.addNearOpenPoint(new Point(x - 1, y), point2);
		this.addNearOpenPoint(new Point(x + 1, y), point2);
		this.addNearOpenPoint(new Point(x, y - 1), point2);
		this.addNearOpenPoint(new Point(x, y + 1), point2);
		if(this.nearOutMap.size() == 0) {
			List<Point> list = new ArrayList<Point>(openMap.values());
			Collections.sort(list, new Comparator<Point>() {

				@Override
				public int compare(Point o1, Point o2) {
					// TODO Auto-generated method stub
					double l1 = o1.gCost;
					double l2 = o2.gCost;
					if(l1 > l2) {
						return 1;
					} else if(l1 < l2){
						return -1;
					} else {
						return 0;
					}
				}
				
			});
			if(list.size() > 0) {
				Point p = list.get(0);
				this.closeMap.put(p.getKey(), p);
				this.openMap.remove(p.getKey());
				this.toNearPoint(list.get(0), point2);
			}
		}
	}

	private void addNearOpenPoint(Point point1, Point point2) {
		// TODO Auto-generated method stub
		String key = point1.getKey();
		double gCost = this.getGuessLength(point1.x, point1.y, 
				point2.x, point2.y);
		point1.gCost = gCost;
		if(PointInStaticObstacle(point1)) {
				if(!this.openMap.containsKey(key) && !this.closeMap.containsKey(key)) {
					this.openMap.put(key, point1);
				}
			} else {
				this.nearOutMap.put(key, point1);
			}	
	}
		public Map<String, Point> getOpenMap(){
			return openMap;
		}
		
		public void setOpenMap(Map<String, Point> openMap) {
			this.openMap = openMap;
		}
		
		public Map<String, Point> getCloseMap(){
			return closeMap;
		}
		
		public void setCloseMap(Map<String, Point> closeMap) {
			this.closeMap = closeMap;
		}
		
		/*public Set<Point> getBarrier() {
			return barrier;
		}
		
		public void setBarrier(Set<Point> barrier) {
			this.barrier = barrier;
		}
		*/
		
		public Point getEndPoint() {
			return endPoint;
		}
		
		public void setEndPoint(Point endPoint) {
			this.endPoint = endPoint;
		}
		
		public Point getStartPoint() {
			return startPoint;
		}
		
		public void setStartPoint(Point startPoint) {
			this.startPoint = startPoint;
		}
		
		
		
		
		
	

}
