package solver;

public class Point {
	/**
	 * define the point in the map.
	 * @param x, y, gCost, hEstimate, fTotal
	 */
	
	double x;
	double y;
	double gCost;
	double angle;
	double hEstimate;
	double fTotal;
	
	Point prev;
	int level = 1;
	
	public String getKey() {
		return x+"_"+y;
	}
	
	public Point(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	public Point(double x, double y, double gCost) {
		super();
		this.x = x;
		this.y = y;
		this.gCost = gCost;
	}
	public Point(double x, double y, double gCost ,double angle) {
		super();
		this.x = x;
		this.y = y;
		this.gCost = gCost;
		this.angle = angle;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + x);
		result = (int) (prime * result + y);
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		if(obj == null)
			return false;
		if(getClass() != obj.getClass())
			return false;
		Point other = (Point) obj;
		if(x != other.x)
			return false;
		if(y != other.y)
			return false;
		return true;
		
	}

}
