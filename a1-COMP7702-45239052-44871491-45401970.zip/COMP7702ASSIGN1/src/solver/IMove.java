package solver;

import java.util.Set;

import problem.MovingBox;
import problem.RobotConfig;
import problem.StaticObstacle;

public interface IMove {
	/**
	 * search ways from point1 to point2
	 * @param robot
	 * @param movingBox
	 * @param goal
	 * @param staticObstacle
	 * @param barrier a list of ways with sequence
	 */
	
	Point move(RobotConfig robot, MovingBox movingBox1, Point goal, double robotWidth,
			StaticObstacle staticObstacle1, StaticObstacle staticObstacle2);
	/*Point Robotmove(RobotConfig robot, MovingBox movingBox, Point goal, 
			StaticObstacle staticObstacle);*/
}
