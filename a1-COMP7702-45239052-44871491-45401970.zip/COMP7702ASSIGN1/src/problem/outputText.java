package problem;

import java.io.*;

public class outputText{
	//加output method
	public static void outputT(RobotConfig r, MovingBox box1, MovingBox box2){
		String outputString = r.robotInfo + box1.boxInfo + box2.boxInfo;

	    try{
	    	File f = new File("output4.txt");
	        append(outputString, f);
	    }
	    catch(IOException e){
	    	System.out.print("Errors occur when trying to output the path data to the text file.");
	    }
	}

	//加append method
	public static void append(String info, File f) throws IOException{
		FileWriter output = new FileWriter(f, true);
	    output.write(info);
	    output.close();
	}
}
